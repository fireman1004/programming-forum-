<!-- This is an example of how you can use TinyMCE for course creation
within your LMS. You can also adapt this starter config to suit the needs of
students - for example to enable them to create assignments or collaborate on
groupwork. -->

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>texteditor</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tiny.cloud/1/ec7zb6c6k0t45anav15qo4hnbe82359dn7r34biibff2pzr3/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
      // TinyMCE Learning Management System (LMS) Starter Config
      // An array containing the available tokens for the tokens dropdown
      var tokens = [
          { text: "student.name", value: "{{student.name}}" },
          { text: "course.name", value: "{{course.name}}" },
          { text: "assignment.name", value: "{{assignment.name}}" },
          { text: "assignment.id", value: "{{assignment.id}}" },
          { text: "assignment.duedate", value: "{{assignment.duedate}}" },
      ];

      tinymce.init({
        // Select the element(s) to add TinyMCE to using any valid CSS selector
        selector: "#editor",

        // Tip - To make TinyMCE leaner, only include the plugins you need
        plugins: "code a11ychecker autosave autoresize link image table lists media mediaembed tinymcespellchecker powerpaste emoticons charmap linkchecker checklist tinycomments charmap preview fullscreen",

        // Specify the toolbar buttons
        // We have put our custom insert token button last
        // https://www.tiny.cloud/docs/tinymce/6/toolbar-configuration-options/
        toolbar: "undo redo | blocks | bold italic underline strikethrough forecolor backcolor | align checklist bullist numlist indent outdent | link image media table | subscript superscript charmap blockquote | tokens | spellchecker a11ycheck  |  addcomment showcomments | fullscreen preview",

        // Disable the status bar
        // https://www.tiny.cloud/docs/tinymce/6/statusbar-configuration-options/#statusbar
        statusbar: false,

        // Enable sticky toolbar
        // https://www.tiny.cloud/docs/tinymce/6/menus-configuration-options/#toolbar_sticky
        toolbar_sticky: true,

        // Set Enhanced Media Embed's max width
        // https://www.tiny.cloud/docs/tinymce/6/introduction-to-mediaembed/
        mediaembed_max_width: 800,

        // You can assign each item in the Blocks menu a user-friendly name
        // https://www.tiny.cloud/docs/tinymce/6/user-formatting-options/#block_formats
        block_formats: 'Title=h1; Heading=h2; Sub heading=h3; Blockquote=blockquote; Paragraph=p',

        // Use font_css to load custom fonts from an external source
        // https://www.tiny.cloud/docs/tinymce/6/add-css-options/#font_css
        font_css: ['https://fonts.googleapis.com/css2?family=Asap:ital,wght@0,400;0,550;1,400&display=swap'], // URLs containing commas and such have to be wrapped in an array to work

        // Set options for Accessibility Checker
        // https://www.tiny.cloud/docs/tinymce/6/a11ychecker/
        a11y_advanced_options: true,
        a11ychecker_html_version: 'html5',
        a11ychecker_level: 'aa',


        // The noneditable_regexp option transforms matched text into spans which is then
        // visually styled to look like tags.
        // https://www.tiny.cloud/docs/tinymce/6/content-behavior-options/#noneditable_regexp
        noneditable_regexp: /{{[^}]+}}/g, // matches {{handlebar}},

        // Here we specify some text formatting shortcuts, as well as
        // some blacklisted words/emojis
        text_patterns: [
            { start: 'darnit', replacement: '🤬' },
            { start: '💩', replacement: '😊' },
            { start: '1/2', replacement: '1/2' },
            { start: '--', replacement: '--' },
            { start: '(c)', replacement: '(c)' },
            { start: '->', replacement: '→' },
            { start: '* ', cmd: 'InsertUnorderedList' },
            { start: '1. ', cmd: 'InsertOrderedList', value: { 'list-style-type': 'decimal' } },
            { start: '#', format: 'h1' },
            { start: '##', format: 'h2' },
            { start: '###', format: 'h3' },
        ],

        setup: (editor) => {
            // Register a custom toolbar menu button to insert tokens
            // https://www.tiny.cloud/docs/tinymce/6/custom-toolbarbuttons/
            editor.ui.registry.addMenuButton("tokens", {
                text: "Token",
                tooltip: "Insert token",
                fetch: (callback) => {
                    var items = tokens.map((token) => {
                        return {
                            type: "menuitem",
                            text: token.text,
                            onAction: () => {
                                // Insert content at the location of the cursor.
                                // https://www.tiny.cloud/docs/tinymce/6/apis/tinymce.editor/#insertContent
                                editor.insertContent(token.value);
                            }
                        }
                    });
                    callback(items);
                }
            });
        },

        // The Tiny Comments plugin enables you to quickly get collaboration up and
        // running. There are a lot of options, but here are the most basic
        // ones to get you started
        // https://www.tiny.cloud/docs/tinymce/6/introduction-to-tiny-comments/
        tinycomments_mode: 'embedded',
        tinycomments_author: 'john.doe',
        tinycomments_author_name: 'John Doe',

        // The following css will be injected into the editor, extending
        // the default styles.
        // In a real world scenario, with much more custom styles for headings
        // links, tables, images etc, it's recommended to use the content_css
        // option to load a separate CSS file. Makes editing easier too.
        // https://www.tiny.cloud/docs/tinymce/6/add-css-options/
        content_style: `
            body {
                max-width: 800px;
                margin: auto;
                font-family: 'Asap', serif;
                font-size: 17px;
                color: #222f3e;
            }

            h1, h2, h3, strong {
                font-weight: 550;
            }

            .mceNonEditable {
                padding: 1px 0;
                color: #44719B;
                font-family: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
                font-size: 0.9375em;
            }

            table th,
            table thead td {
                background-color: #ecf0f1;
                font-weight: 550;
                text-align: left;
            }

            table caption {
                display: none;
            }

            table[data-mce-selected="1"] caption {
                display: table-caption;
            }
            `

        // Next step: Check out Tiny Drive for easy cloud storage of your users'
        // images and media. Integrates seamlessly with TinyMCE.
        // https://www.tiny.cloud/drive/

      });
    </script>
    <style>
        body {
            margin: 60px 16px;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", Helvetica, Arial, sans-serif;
            background-color: #fafafc;
            font-family: 'Asap', serif;
            color: #222f3e;
        }

        .editor-wrap {
            max-width: 1200px;
            margin: auto;
        }
    </style>
</head>
<body>

<div class="editor-wrap">
    <textarea id="editor">
   
    </textarea>
</div>

</body>
</html>