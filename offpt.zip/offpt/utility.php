<?php
error_reporting(1);
	function ExecuteQuery ($SQL)
	{	
		$con=mysqli_connect ("localhost", "root","","tech_forum");
		
		$rows = mysqli_query ($con, $SQL);
		
		return $rows;

		mysqli_close (); 
		
	}
	
	function ExecuteNonQuery ($SQL)
	{
		$con=mysqli_connect ("localhost", "root","","tech_forum");
		
		$result = mysqli_query ($con, $SQL);
		
		return $result;

		mysqli_close ();
		
	}
?>