<?php require("header.php");?>
<?php
echo "<h1> YOU ARE REGISTERED </h1> " ;
echo "click Here to log-in <a href='index.php'>click Here</a>";
?>
<?php require("footer.php");?>