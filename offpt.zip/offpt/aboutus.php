<?php 
require("header.php");
//require("checkUser.php")?>

<script type="text/javascript">
	document.getElementById("aaboutus").className="active";
</script>

 <div class="art-PostContent">
 <div class="art-contentLayout">
                   
                            
<p align="justify">The <b>Online Forum For Programming Toturails(OFFPT)</b> is a discussion forum that gives information about various programming languages, general knowledge related questions, information related to Asp.net,Vb.net ,Java,Php,Os related questions,etc. </p>

<p align="justify">This forum is useful for the beginners to get information  related to  various topics.
	 There is a centralized database in which all the information is managed.
	  The administrator acts as the highest authority and has the rights to update, 
	  delete and edit the database. The user has to create the account to access the data. 
	  Once the user has created the account in the database he becomes the connected user. 
	  When some other user asks the  questions these connected user if  knows the answer
	   can reply the answer it. The user who logged in can select the questions according to the category. 
	   The administrator can insert new topic  dynamically. The connected user while logged in can exchange messages with each other. 
	   If the message is present in the database the answer is received to the person who asked the question immediately. 
	   When the user asks the question related to any topic all the related question  and their 
	   answers will be displayed. This site also gives the number of times the question is viewed and  number of times the question is answered. 
	   This site also gives us information who had asked the questions and which users has replied to those question.  </p>

 <p>
                                	<span class="art-button-wrapper">
                                		<span class="l"> </span>
                                		<span class="r"> </span>
                                		<a class="art-button" href="contact.php">Contact Info...</a>
                                	</span>
                                </p>
</div>
</div>
</div>
</div>
</div>



<?php require("footer.php")?>